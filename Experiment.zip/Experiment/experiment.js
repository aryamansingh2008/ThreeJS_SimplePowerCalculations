
var lampBulb;
var helpContent;
var infoContent;
var Switch;
var aneedle;
var needle;
var arrow1a;
var arrow1b;
var arrow2a;
var arrow2b;
var arrow3a;
var arrow3b;
var arrow4a;
var thevel2;
var thevel3;
var arrow4b;
var temp;
var battext;
var voltage;
var resistance;
var check;
var information;
var clock;
var sec=[];
var min=[];
var a;
var b;
var ab;
var lm;
var power;
var power2;
var power3;
var powerplain;
var calc;
var calc2;
var flag ;

function pro()
{
	var calc2 = prompt("Enter Value of Power (in Watt, correct to exactly 2 decimal places)", "0");
	if(calc==calc2)
			alert("CORRECT");
	else
		alert("INCORRECT, TRY AGAIN");
}

function learningtext()
{
	var loader = new THREE.FontLoader();
    loader.load("optimer.json", function(response){
        font = response;
		
		geometry = new THREE.TextGeometry('Calculate the Power(P)', {
        	font : font,
            size : 0.2,
            height : 0.02,
        });
		power2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        power2.translation = geometry.center();
        PIEaddElement(power2);
        power2.castShadow=false;
        power2.visible=false;
        power2.position.set(-6.6,1.3,5);
   		//power.lookAt(PIEcamera.position);
		
		geometry = new THREE.TextGeometry('Click here to enter.', {
        	font : font,
            size : 0.2,
            height : 0.02,
        });
		power3=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        power3.translation = geometry.center();
        PIEaddElement(power3);
        power3.castShadow=false;
        power3.visible=false;
        power3.position.set(-6.6,0.9,5);
		
		geometry = new THREE.TextGeometry('Power(W) = Voltage(V) x Current(A)', {
        	font : font,
            size : 0.2,
            height : 0.02,
        });
		power=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:0xffe39f}));
        power.translation = geometry.center();
        PIEaddElement(power);
        power.castShadow=false;
        power.visible=false;
        power.position.set(-6.4-0.1,1.9,5);
	});
	
	var geometry=new THREE.PlaneGeometry(3.8,1.2,1);
	var material = new THREE.MeshBasicMaterial( {color: "black", side: THREE.DoubleSide} );
	powerplain = new THREE.Mesh( geometry, material );
	powerplain.position.set(-7.59,1.28,2);
	PIEaddElement(powerplain);
	powerplain.visible=false;
	PIEsetClick(powerplain,pro);
}

function batterytext()
{
	var loader = new THREE.FontLoader();
    loader.load("optimer.json", function(response){
        font = response;
		
		geometry = new THREE.TextGeometry(voltage +' V', {
        	font : font,
            size : 0.25,
            height : 0.03,
        });
		battext=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"white"}));
        battext.translation = geometry.center();
        PIEaddElement(battext);
        battext.castShadow=false;
        battext.visible=true;
        battext.position.set(-6.1,-1.9,5);
   		//battext.lookAt(PIEcamera.position);
	});
}

function voltagecontrol(newVal)
{
	PIEremoveElement(battext);
	voltage=newVal;
	
	batterytext();
	PIErender();
}

function initialiseHelp()
{
    helpContent="";
    helpContent = helpContent + "<h2>Simple power (wattage) calculations help</h2>";
    helpContent = helpContent + "<h3>About the experiment</h3>";
    helpContent = helpContent + "<p>Shown the calculation of power in wattage.<p>";
	helpContent = helpContent + "<p>The running time of an experiment is calculated through the stopwatch which can be paused at any time by clicking on it.<p>";
    helpContent = helpContent + "<h3>Animation control for Experiment Mode</h3>";
    helpContent = helpContent + "<p>Select the value of voltage through the slider</p>";
    helpContent = helpContent + "<p>The deflection in the ammeter shows the current in the circuit.</p>";
    helpContent = helpContent + "<p>The deflection in the multimeter shows the voltage across the electrical appliance.</p>";
	helpContent = helpContent + "<p>The table gets filled as the animation is started.</p>";
    helpContent = helpContent + "<p>Click on pause button to pause the animation</p>";
    helpContent = helpContent + "<p>Click on Reset button to reset animation</p>";
	helpContent = helpContent + "<h3>Animation control for Learning Mode</h3>";
	helpContent = helpContent + "<p>The value of voltage is randomly selected. You can also select the value from the slider.</p>";
    helpContent = helpContent + "<p>The deflection in the ammeter shows the current in the circuit.</p>";
    helpContent = helpContent + "<p>The deflection in the multimeter shows the voltage across the electrical appliance.</p>";
	helpContent = helpContent + "<p>The table gets filled as the animation is started with the current, voltage and resistance value.</p>";
    helpContent = helpContent + "<p>The value of the power across the electrical appliance should be calculated by the user.</p>";
	helpContent = helpContent + "<p>Enter the calculated value of power to check whether if it is correct or not.</p>";
	helpContent = helpContent + "<p>Click on pause button to pause the animation</p>";
    helpContent = helpContent + "<p>Click on Reset button to reset animation</p>";
    infoContent = infoContent + "<h2>Happy Experimenting</h2>";
    PIEupdateHelp(helpContent);
}

function initialiseInfo()
{
    infoContent =  "";
    infoContent = infoContent + "<h2>Simple power (wattage) calculations concepts</h2>";
    infoContent = infoContent + "<h3>About the experiment</h3>";
    infoContent = infoContent + "<p>Shown the calculation of power in wattage.</p>";
    infoContent = infoContent + "<p>The power is the product of voltage and current across an electrical appliance.</p>";
	infoContent = infoContent + "<p>There are a various expressions in which the relation between power, current, voltage and resistance can be expressed :-</p>";
	infoContent = infoContent + "<h3>Power = Voltage x Current</h3>";
	infoContent = infoContent + "<h3>Power = Current x Current x Resistance</h3>";
	infoContent = infoContent + "<h3>Power = (Voltage x Voltage) / Current</h3>";
	infoContent = infoContent + "<p>In the experiment, the values of current is calculated by the ammeter.</p>";
	infoContent = infoContent + "<p>The values of the voltage across the electrical appliance is calculated by the multimeter.</p>";
	infoContent = infoContent + "<p>The values of the resistance of the bulb is fixed and is equal to 1500 ohms.</p>";
	infoContent = infoContent + "<p>The electric power in watts associated with a complete electric circuit or a circuit component represents the rate at which energy is converted from the electrical energy of the moving charges to some other form, e.g., heat, mechanical energy, or energy stored in electric fields or magnetic fields. For a resistor in a D C Circuit, the power is given by the product of applied voltage and the electric current.</p>";
	
    PIEupdateInfo(infoContent);
}

function clockzero()
{
		for(var i=0;i<60;i++)
		{
			sec[i].visible=false;
			min[i].visible=false;
		}
	sec[0].visible=true;
	min[0].visible=true;
}

function PIEcreateTable(i,n,g,d)
{
	var c;var b;var m;var f;var a;var h;var l;var k;var j;var e;PIEtableChangeHandlers.push(null);PIEtableNames.push(i);PIEtableRows.push(new Array(0));PIEtableData.push(new Array(0));PIEtableChangeHandlers.push(null);PIEcurrentTable=PIEtableNames.length-1;c=document.createElement("div");c.draggable=true;c.addEventListener("dragstart",PIEtableDragStart,false);c.id="mytable";c.style.border="2px solid white";c.style.borderRadius="10px";c.style.display="inline-block";c.style.position="absolute";c.style.top="20px";c.style.color="white";document.body.appendChild(c);b=document.createElement("div");b.style.display="inline-block";b.style.width="100%";b.style.padding="0px";c.appendChild(b);m=document.createElement("p");m.style.display="inline-block";m.style.width="100%";m.style.margin="auto";m.style.border="2 px solid white";m.style.borderRadius="10px";m.style.backgroundColor="#0020AA";b.appendChild(m);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableAdd.png";a.alt="add";a.height="16";a.width="16";a.style.display="inline";f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableDelete.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";a=document.createElement("span");a.style.padding="5px";a.style.margin="auto";a.style.align="center";a.innerHTML="<b>"+i+"</b>";m.appendChild(a);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";f.style.align="right";f.addEventListener("click",PIEtoggleTable,false);m.appendChild(f);a=document.createElement("img");a.src="../PIE/images/TableFold.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";f.appendChild(a);a=document.createElement("div");h=document.createElement("table");h.style.display="inline-block";h.style.border="1px solid white";h.style.borderRadius="10px";h.style.padding="0px";h.style.backgroundColor="#0040BB";PIEtables.push(h);a.appendChild(h);c.appendChild(a);for(j=0;j<n;j++){for(e=0;e<g;e++){if(j==0){k=PIEcreateTableCell(j,e,d)}else{k=PIEcreateTableCell(j,e,false)}}}PIEupdateTable(PIEtables[PIEcurrentTable])
}

function PIEcreateTable1(i,n,g,d)
{
	var c;var b;var m;var f;var a;var h;var l;var k;var j;var e;PIEtableChangeHandlers.push(null);PIEtableNames.push(i);PIEtableRows.push(new Array(0));PIEtableData.push(new Array(0));PIEtableChangeHandlers.push(null);PIEcurrentTable=PIEtableNames.length-1;c=document.createElement("div");c.draggable=true;c.addEventListener("dragstart",PIEtableDragStart,false);c.id="mytable2";c.style.border="2px solid white";c.style.borderRadius="10px";c.style.display="inline-block";c.style.position="absolute";c.style.top="20px";c.style.color="white";document.body.appendChild(c);b=document.createElement("div");b.style.display="inline-block";b.style.width="100%";b.style.padding="0px";c.appendChild(b);m=document.createElement("p");m.style.display="inline-block";m.style.width="100%";m.style.margin="auto";m.style.border="2 px solid white";m.style.borderRadius="10px";m.style.backgroundColor="#0020AA";b.appendChild(m);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableAdd.png";a.alt="add";a.height="16";a.width="16";a.style.display="inline";f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableDelete.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";a=document.createElement("span");a.style.padding="5px";a.style.margin="auto";a.style.align="center";a.innerHTML="<b>"+i+"</b>";m.appendChild(a);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";f.style.align="right";f.addEventListener("click",PIEtoggleTable,false);m.appendChild(f);a=document.createElement("img");a.src="../PIE/images/TableFold.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";f.appendChild(a);a=document.createElement("div");h=document.createElement("table");h.style.display="inline-block";h.style.border="1px solid white";h.style.borderRadius="10px";h.style.padding="0px";h.style.backgroundColor="#0040BB";PIEtables.push(h);a.appendChild(h);c.appendChild(a);for(j=0;j<n;j++){for(e=0;e<g;e++){if(j==0){k=PIEcreateTableCell(j,e,d)}else{k=PIEcreateTableCell(j,e,false)}}}PIEupdateTable(PIEtables[PIEcurrentTable])
}

function mybattery( x, y, z)
{
    var a = 4;
    cuboidOrange =  new THREE.Mesh( new THREE.CubeGeometry( 4/a, 5/a, 2/a, 4, 4, 1 ),new THREE.MeshBasicMaterial({color: "orange"}));
    cuboidOrange.position.set(x,y,z);
    PIEaddElement(cuboidOrange);

    var curve1O = new THREE.Mesh(new THREE.CylinderGeometry(1/a,1/a,4/a,32),new THREE.MeshBasicMaterial({color:"orange"}));
    curve1O.position.set(x,y+2.5/a,z);
    cuboidOrange.add(curve1O);
    curve1O.rotation.z = Math.PI/2;

    var curve2O = new THREE.Mesh(new THREE.CylinderGeometry(1/a,1/a,4/a,32),new THREE.MeshBasicMaterial({color:"orange"}));
    curve2O.position.set(x,y-2.5/a,z);
    cuboidOrange.add(curve2O);
    curve2O.rotation.z = Math.PI/2;

    var cuboidBlack =  new THREE.Mesh( new THREE.CubeGeometry( 6/a, 5/a, 2/a, 4, 4, 1 ),new THREE.MeshBasicMaterial({color: "black"}));
    cuboidBlack.position.set(x+5/a,y,z);
    cuboidOrange.add(cuboidBlack);

    var curve1B = new THREE.Mesh(new THREE.CylinderGeometry(1/a,1/a,6/a,32),new THREE.MeshBasicMaterial({color:"black"}));
    curve1B.position.set(x+5/a,y+2.5/a,z);
    cuboidOrange.add(curve1B);
    curve1B.rotation.z = Math.PI/2;

    var curve2B = new THREE.Mesh(new THREE.CylinderGeometry(1/a,1/a,6/a,32),new THREE.MeshBasicMaterial({color:"black"}));
    curve2B.position.set(x+5/a,y-2.5/a,z);
    cuboidOrange.add(curve2B);
    curve2B.rotation.z = Math.PI/2;

    var minus =  new THREE.Mesh( new THREE.CubeGeometry( 2/a, 0.3/a, 0.1/a, 4, 4, 1 ),new THREE.MeshBasicMaterial({color: "red"}));
    minus.position.set(x,y+2.5/a,z+1.1/a);
    cuboidOrange.add(minus);

    var plus1 =  new THREE.Mesh( new THREE.CubeGeometry( 2/a, 0.3/a, 0.1/a, 4, 4, 1 ),new THREE.MeshBasicMaterial({color: "red"}));
    plus1.position.set(x,y-1.5/a,z+1.1/a);
    cuboidOrange.add(plus1);

    plus2 =  new THREE.Mesh( new THREE.CubeGeometry( 2/a, 0.3/a, 0.1/a, 4, 4, 1 ),new THREE.MeshBasicMaterial({color: "red"}));
    plus2.position.set(x,y-1.5/a,z+1.1/a);
    cuboidOrange.add(plus2);
    plus2.rotation.z=Math.PI/2;

    var terminal1 = new THREE.Mesh(new THREE.CylinderGeometry(0.5/a,0.5/a,0.5/a,32),new THREE.MeshBasicMaterial({color:"gray"}));
    terminal1.position.set(x-2.2/a,y+2.2/a,z);
    cuboidOrange.add(terminal1);
    terminal1.rotation.z = Math.PI/2;

    var terminal2 = new THREE.Mesh(new THREE.CylinderGeometry(0.5/a,0.5/a,0.5/a,32),new THREE.MeshBasicMaterial({color:"gray"}));
    terminal2.position.set(x-2.2/a,y-2.2/a,z);
    cuboidOrange.add(terminal2);
    terminal2.rotation.z = Math.PI/2;

    cuboidOrange.position.x += -5.5;
    cuboidOrange.position.y += -2;
    cuboidOrange.position.z += 3;
    cuboidOrange.rotation.z = Math.PI;
    //cuboidOrange.rotation.x = -Math.PI/8;
}

function addAmmeter()
{
	var geometry=new THREE.CircleGeometry(1.4,32);
	var material = new THREE.MeshBasicMaterial( {color: "grey", side: THREE.DoubleSide} );
	var aplane1 = new THREE.Mesh( geometry, material );
	aplane1.position.set(-1.3,1.7,0);
	
	var geometry=new THREE.CircleGeometry(1.28,32);
	var material = new THREE.MeshBasicMaterial( {color: "white", side: THREE.DoubleSide} );
	var aplane2 = new THREE.Mesh( geometry, material );
	aplane2.position.set(0,0,0.01);
	aplane1.add(aplane2);
	
	var geometry=new THREE.PlaneGeometry(0.05,2.1,1);
	var material = new THREE.MeshBasicMaterial( {color: "black", side: THREE.DoubleSide} );
	aneedle = new THREE.Mesh( geometry, material );
	aneedle.position.set(0,0,0.03);
	aplane1.add(aneedle);
	
	
	var geometry=new THREE.PlaneGeometry(0.05,0.25,1);
	var material = new THREE.MeshBasicMaterial( {color: "black", side: THREE.DoubleSide} );
	var aneedletop1 = new THREE.Mesh( geometry, material );
	aneedletop1.position.set(0.06,1,0);
	aneedletop1.rotation.z=Math.PI/6;
		
	aneedle.add(aneedletop1);
		
	var geometry=new THREE.PlaneGeometry(0.05,0.25,1);
	var material = new THREE.MeshBasicMaterial( {color: "black", side: THREE.DoubleSide} );
	var aneedletop2 = new THREE.Mesh( geometry, material );
	aneedletop2.position.set(-0.06,1,0);
	aneedletop2.rotation.z=-Math.PI/6;
	aneedle.add(aneedletop2);
	
	var geometry=new THREE.PlaneGeometry(2,0.6,2);
	var material = new THREE.MeshBasicMaterial( {color: "white", side: THREE.DoubleSide} );
	var aplane3 = new THREE.Mesh( geometry, material );
	aplane3.position.set(0,-0.37,0.03);
	aplane1.add(aplane3);
	
	var geometry=new THREE.PlaneGeometry(0.99,0.9,2);
	var material = new THREE.MeshBasicMaterial( {color: "white", side: THREE.DoubleSide} );
	var cover2 = new THREE.Mesh( geometry, material );
	cover2.position.set(0,-0.7,0.031);
	aplane1.add(cover2);
	
	var geometry=new THREE.PlaneGeometry(1.55,0.5,2);
	var material = new THREE.MeshBasicMaterial( {color: "white", side: THREE.DoubleSide} );
	var cover3 = new THREE.Mesh( geometry, material );
	cover3.position.set(0,-0.7,0.032);
	aplane1.add(cover3);
	
	var geometry=new THREE.CircleGeometry(0.1,32);
	var material = new THREE.MeshBasicMaterial( {color: "black", side: THREE.DoubleSide} );
	var aplane4 = new THREE.Mesh( geometry, material );
	aplane4.position.set(0,0,0.03);
	aplane1.add(aplane4);
	
	var geometry=new THREE.PlaneGeometry(2.55,0.05,1);
	var material = new THREE.MeshBasicMaterial( {color: "black", side: THREE.DoubleSide} );
	var aplane5 = new THREE.Mesh( geometry, material );
	aplane5.position.set(0,-0.05,0.03);
	aplane1.add(aplane5);
	
	var geometry=new THREE.PlaneGeometry(0.3,0.05,1);
	var material = new THREE.MeshBasicMaterial( {color: "red", side: THREE.DoubleSide} );
	var plus1 = new THREE.Mesh( geometry, material );
	plus1.position.set(-1,0.2,0.02);
	aplane1.add(plus1);
	
	var geometry=new THREE.PlaneGeometry(0.05,0.3,1);
	var material = new THREE.MeshBasicMaterial( {color: "red", side: THREE.DoubleSide} );
	var plus2 = new THREE.Mesh( geometry, material );
	plus2.position.set(-1,0.2,0.02);
	aplane1.add(plus2);
	
	var geometry=new THREE.PlaneGeometry(0.3,0.05,1);
	var material = new THREE.MeshBasicMaterial( {color: "red", side: THREE.DoubleSide} );
	var minus = new THREE.Mesh( geometry, material );
	minus.position.set(1,0.2,0.02);
	aplane1.add(minus);
	
	PIEaddElement(aplane1);
	
	
	//PIEdragElement(aplane1);
	
	//aneedle.rotation.z=Math.PI/5;
}

function addMM()
{
		var geometry=new THREE.PlaneGeometry(2,3,1);
		var material = new THREE.MeshBasicMaterial( {color: "grey", side: THREE.DoubleSide} );
		var plane1 = new THREE.Mesh( geometry, material );
		plane1.position.set(9,-2,0);
		PIEaddElement(plane1);

		var geometry=new THREE.PlaneGeometry(1.75,1.5,1);
		var material = new THREE.MeshBasicMaterial( {color: "white", side: THREE.DoubleSide} );
		var plane2 = new THREE.Mesh( geometry, material );
		plane2.position.set(9,-1.4,0);
		PIEaddElement(plane2);
			
		var geometry = new THREE.CircleGeometry( 0.55, 32 );
		var material = new THREE.MeshBasicMaterial( { color: 0xffff00 } );
		var circle = new THREE.Mesh( geometry, material );
		circle.position.set(9,-2.8,0);
		PIEaddElement( circle );	
		
		var geometry=new THREE.PlaneGeometry(0.1,0.8,1);
		var material = new THREE.MeshBasicMaterial( {color: "red", side: THREE.DoubleSide} );
		var plane3 = new THREE.Mesh( geometry, material );
		plane3.position.set(9,-2.8,0.1);
		plane3.rotation.z=-Math.PI/4;
		PIEaddElement(plane3);
		
		var geometry=new THREE.PlaneGeometry(0.05,1.38,1);
		var material = new THREE.MeshBasicMaterial( {color: "black", side: THREE.DoubleSide} );
		needle = new THREE.Mesh( geometry, material );
		needle.position.set(9,-1.4,0.1);
		
	
		var geometry=new THREE.PlaneGeometry(0.05,0.25,1);
		var material = new THREE.MeshBasicMaterial( {color: "black", side: THREE.DoubleSide} );
		var needletop1 = new THREE.Mesh( geometry, material );
		needletop1.position.set(0.02,0.58,0.1);
		needletop1.rotation.z=Math.PI/6;
		
		needle.add(needletop1);
		
		var geometry=new THREE.PlaneGeometry(0.05,0.25,1);
		var material = new THREE.MeshBasicMaterial( {color: "black", side: THREE.DoubleSide} );
		var needletop2 = new THREE.Mesh( geometry, material );
		needletop2.position.set(-0.06,0.58,0);
		needletop2.rotation.z=-Math.PI/6;
		needle.add(needletop2);
		
		var geometry = new THREE.CircleGeometry( 0.1, 32 );
		var material = new THREE.MeshBasicMaterial( { color: "black" } );
		var circle2 = new THREE.Mesh( geometry, material );
		circle2.position.set(0,0,0);
		needle.add(circle2);
		
		PIEaddElement(needle);
		
		var geometry = new THREE.PlaneGeometry(1.5,0.6,1);
		var material = new THREE.MeshBasicMaterial( {color: "grey", side: THREE.DoubleSide} );
		var screen = new THREE.Mesh( geometry, material );
		screen.position.set(8.955,-1.79,0.1);
		PIEaddElement(screen);
		
		//needle.rotation.z=Math.PI/6;
}

function startText()
{
	temp =((voltage/resistance)*1000).toFixed(2);
	var loader = new THREE.FontLoader();
    loader.load("optimer.json", function(response){
        font = response;
		
		geometry = new THREE.TextGeometry(temp +' mA', {
        	font : font,
            size : 0.25,
            height : 0.03,
        });
		thevel2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"black"}));
        thevel2.translation = geometry.center();
        PIEaddElement(thevel2);
        thevel2.castShadow=false;
        thevel2.visible=true;
        thevel2.position.set(-1.2,1.2,0.5); 
   		//thevel2.lookAt(PIEcamera.position);
		
		geometry = new THREE.TextGeometry(voltage +' V', {
        	font : font,
            size : 0.25,
            height : 0.03,
        });
		thevel3=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"black"}));
        thevel3.translation = geometry.center();
        PIEaddElement(thevel3);
        thevel3.castShadow=false;
        thevel3.visible=true;
        thevel3.position.set(8.8,-1.8,0.5); 
   		//thevel3.lookAt(PIEcamera.position);
	});
}

function stopText()
{
	thevel2.visible=false;
	thevel3.visible=false;
}

function addText()
{
	var loader = new THREE.FontLoader();
    loader.load("optimer.json", function(response){
        font = response;
		
		geometry = new THREE.TextGeometry('AMMETER', {
        	font : font,
            size : 0.2,
            height : 0.02,
        });
		var thevel3=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"white"}));
        thevel3.translation = geometry.center();
        PIEaddElement(thevel3);
        thevel3.castShadow=false;
        thevel3.visible=true;
        thevel3.position.set(-0.9,2.7,5); 
   		//thevel3.lookAt(PIEcamera.position);
		
		geometry = new THREE.TextGeometry('STOP WATCH', {
        	font : font,
            size : 0.2,
            height : 0.02,
        });
		var thevel31=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"white"}));
        thevel31.translation = geometry.center();
        PIEaddElement(thevel31);
        thevel31.castShadow=false;
        thevel31.visible=true;
        thevel31.position.set(6.2,1.8,0.01); 
   		//thevel31.lookAt(PIEcamera.position);
		
		geometry = new THREE.TextGeometry('MULTIMETER', {
        	font : font,
            size : 0.2,
            height : 0.02,
        });
		var thevel4=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"white"}));
        thevel4.translation = geometry.center();
        PIEaddElement(thevel4);
        thevel4.castShadow=false;
        thevel4.visible=true;
        thevel4.position.set(8.3,-0.05,2); 
   		//thevel4.lookAt(PIEcamera.position);
		
		geometry = new THREE.TextGeometry('V', {
        	font : font,
            size : 0.15,
            height : 0.05,
        });
		var thevel6=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"red"}));
        thevel6.translation = geometry.center();
        PIEaddElement(thevel6);
        thevel6.castShadow=false;
        thevel6.visible=true;
        thevel6.position.set(7.85,-1.95,5); 
   		//thevel6.lookAt(PIEcamera.position);
		
		
		geometry = new THREE.TextGeometry(voltage +' V', {
        	font : font,
            size : 0.25,
            height : 0.03,
        });
		battext=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"white"}));
        battext.translation = geometry.center();
        PIEaddElement(battext);
        battext.castShadow=false;
        battext.visible=true;
        battext.position.set(-6,-1.9,5); 
   		//battext.lookAt(PIEcamera.position);
		
		
		geometry = new THREE.TextGeometry('SWITCH', {
        	font : font,
            size : 0.25,
            height : 0.03,
        });
		var thevel5=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"white"}));
        thevel5.translation = geometry.center();
        PIEaddElement(thevel5);
        thevel5.castShadow=false;
        thevel5.visible=true;
        //thevel5.position.set(5.6,-1.55,5); 
		thevel5.position.set(-0.6,-3.55,5); 
   		//thevel5.lookAt(PIEcamera.position);
		
		geometry = new THREE.TextGeometry('_', {
        	font : font,
            size : 0.15,
            height : 0.05,
        });
		var thevel7=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"red"}));
        thevel7.translation = geometry.center();
        PIEaddElement(thevel7);
        thevel7.castShadow=false;
        thevel7.visible=true;
        thevel7.position.set(7,-1.1,5); 
   		//thevel7.lookAt(PIEcamera.position);
		
		geometry = new THREE.TextGeometry('+', {
        	font : font,
            size : 0.2,
            height : 0.02,
        });
		var thevel8=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"red"}));
        thevel8.translation = geometry.center();
        PIEaddElement(thevel8);
        thevel8.castShadow=false;
        thevel8.visible=true;
        thevel8.position.set(7.7,-1.1,5); 
   		//thevel8.lookAt(PIEcamera.position);
    });	
}

function addArrows()
{
	arrow1a = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.7),new THREE.MeshBasicMaterial({ color:"red"}));
	arrow1a.position.set(-3.81,-2,-10000);
	PIEaddElement(arrow1a);
	
	arrow1b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow1b.position.set(-3.81,-2,-10000);
	PIEaddElement(arrow1b);
	
	arrow2a=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow2a.position.set(-2.45,0.7,-10000);
	PIEaddElement(arrow2a);	
	
	arrow2b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow2b.position.set(-2.45,0.7,-10000);
	PIEaddElement(arrow2b);
	
	arrow3a=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow3a.position.set(1.5,0.7,-10000);
	PIEaddElement(arrow3a);
	
	arrow3b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow3b.position.set(1.5,0.7,-10000);
	PIEaddElement(arrow3b);
	
	arrow4a=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow4a.position.set(5.25,-4.2,-10000);
	PIEaddElement(arrow4a);
	
	arrow4b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow4b.position.set(5.25,-4.2,-10000);
	PIEaddElement(arrow4b);
	
}

function noarrows()
{
	arrow1a.position.set(-3.81,-2,-10000);
	arrow1b.position.set(-3.81,-2,-10000);
	arrow2a.position.set(-2.45,0.7,-10000);
	arrow2b.position.set(-2.45,0.7,-10000);
	arrow3a.position.set(1.5,0.7,-10000);
	arrow3b.position.set(1.5,0.7,-10000);
	arrow4a.position.set(5.25,-4.2,-10000);
	arrow4b.position.set(5.25,-4.2,-10000);	
}

function arrowpos_1()
{
	arrow1a.position.set(-4,-2,-1);
	arrow1a.rotation.z=Math.PI/6;
	
	arrow1b.position.set(-3.6,-2,-1);
	arrow1b.rotation.z=-Math.PI/6;
	
	arrow2a.position.set(-2.45,0.9,-1);
	arrow2a.rotation.z=-Math.PI/3;
	
	arrow2b.position.set(-2.45,0.5,-1);
	arrow2b.rotation.z=+Math.PI/3;
	
	arrow3a.position.set(1.5,0.5,-1);
	arrow3a.rotation.z=+Math.PI/3;
	
	arrow3b.position.set(1.5,0.9,-1);
	arrow3b.rotation.z=-Math.PI/3;
	
	arrow4a.position.set(5.48,-4.2,-1);
	arrow4a.rotation.z=+Math.PI/6;
	
	arrow4b.position.set(5.02,-4.2,-1);
	arrow4b.rotation.z=-Math.PI/6;
}

function arrowpos_2()
{
	arrow1a.position.set(-3.6,-2,-1);
	arrow1a.rotation.z=+Math.PI/6;
		
	arrow1b.position.set(-4.02,-2,-1);
	arrow1b.rotation.z=-Math.PI/6;
	
	arrow2a.position.set(-2.45,0.9,-1);
	arrow2a.rotation.z=+Math.PI/3;
	
	arrow2b.position.set(-2.45,0.5,-1);
	arrow2b.rotation.z=-Math.PI/3;
	
	arrow3a.position.set(1.5,0.5,-1);
	arrow3a.rotation.z=-Math.PI/3;
	
	arrow3b.position.set(1.5,0.9,-1);
	arrow3b.rotation.z=+Math.PI/3;
	
	arrow4a.position.set(5.48,-4.2,-1);
	arrow4a.rotation.z=-Math.PI/6;
	
	arrow4b.position.set(5.02,-4.2,-1);
	arrow4b.rotation.z=+Math.PI/6;
}

function addClipper()
{
	Switch = new THREE.Mesh(new THREE.BoxGeometry(1,0.1,0.1),new THREE.MeshBasicMaterial({color:"red"}));
	Switch.position.set(-0.95,-5.14,1);
	//Switch.position.set(-0.9,-5.39,1);
	Switch.rotation.z=-Math.PI/2-Math.PI/3;
	PIEaddElement(Switch);
	
	var box = new THREE.Mesh(new THREE.TorusGeometry(0.83,0.07,100,100),new THREE.MeshPhongMaterial({color:"gray"}));
	box.position.set(-0.9,-5.38,1);
	PIEaddElement(box);
	
}

function addMeter()
{
	
}

function addclocktext()
{
	/*information=document.createElement('div');
    information.style.position="fixed";
    information.style.top = "100px";
    information.style.right = "-440px";
    information.style.width = '100%';
    information.style.textAlign = 'center';
    information.style.color = '#ffffff';
    information.style.fontWeight = 'bold';
    information.style.backgroundColor = 'transparent';
    information.style.zIndex = '1';
    information.style.fontFamily = 'Monospace';
    //var s="bla"
    information.innerHTML = min + ":" + sec;
    document.body.appendChild( information );
    PIErender();*/
	sec2=new Array;
	min2=new Array;
	var x;
	var loader = new THREE.FontLoader();
    loader.load("optimer.json", function(response){
        font = response;
	for(var i=0;i<60;i++)
	{
		if(i<10)
			x='0'+i;
		else
			x=i;
		geometry = new THREE.TextGeometry(':'+x, {
        	font : font,
            size : 0.2,
            height : 0.05,
        });
		var temp=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"black"}));
        temp.translation = geometry.center();
        PIEaddElement(temp);
        temp.castShadow=false;
        temp.visible=false;
        temp.position.set(4.5+1.5,2.2+0.65,1); 
   		//temp.lookAt(PIEcamera.position);
		sec2.push(temp);
		
		geometry = new THREE.TextGeometry(x, {
        	font : font,
            size : 0.2,
            height : 0.05,
        });
		var temp2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"black"}));
        temp2.translation = geometry.center();
        PIEaddElement(temp2);
        temp2.castShadow=false;
        temp2.visible=false;
        temp2.position.set(4.1+1.5,2.2+0.65,1); 
   		//temp2.lookAt(PIEcamera.position);
		min2.push(temp2);
	}
	sec=sec2.slice();
	min=min2.slice();
	//sec[13].visible=true;
	sec[0].visible=true;
	min[0].visible=true;
	});
}

function addclock()
{
	var geometry=new THREE.CircleGeometry(0.9,32);
	var material = new THREE.MeshBasicMaterial( {color: "black", side: THREE.DoubleSide} );
	var watch = new THREE.Mesh( geometry, material );
	watch.position.set(6.05,2.75+0.3,0);
	PIEaddElement(watch);
	
	var geometry=new THREE.CircleGeometry(0.8,32);
	var material = new THREE.MeshBasicMaterial( {color: "white", side: THREE.DoubleSide} );
	var watch2 = new THREE.Mesh( geometry, material );
	watch2.position.set(6.05,2.75+0.3,0);
	PIEaddElement(watch2);
	PIEsetClick(watch2,pauseclock);
	
	var geometry=new THREE.CylinderGeometry(0.1,0.1,0.2);
	var material = new THREE.MeshBasicMaterial( {color: "red", side: THREE.DoubleSide} );
	var watch3 = new THREE.Mesh( geometry, material );
	watch3.position.set(6.05,3.75+0.3,0);
	PIEaddElement(watch3);
}

function pauseclock()
{
	flag++;
}
function deflection()
{
	aneedle.rotation.z=-voltage*Math.PI/700;
	needle.rotation.z=voltage*Math.PI/700;
	if(voltage<50)
		lampBulb.material.color.set(0xFFFF66);
	else
		lampBulb.material.color.set(0xFFFF00);
}

function addWires()
{
	
	 var lw1=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw1.position.set(-5.5,-1.5,-0.4);
	 lw1.rotation.z+=Math.PI*0.5;
	PIEaddElement(lw1);
	
	 var lw2=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.7),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw2.position.set(-5.45,-2.8,-0.4);
	 lw2.rotation.z+=Math.PI*0.5;
	PIEaddElement(lw2);
	 
	
	 var lw2=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,1.42),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw2.position.set(10.48,-5.8,-1);
	 lw2.rotation.z+=Math.PI*0.5;
	PIEaddElement(lw2);
	
	 var lw3=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,9.5),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw3.position.set(4.25,-5.8,-1);
	 lw3.rotation.z+=Math.PI*0.5;
	PIEaddElement(lw3);//switch right
	
	 var lw3b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,3.7),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw3b.position.set(-3.42,-5.8,-1);
	 lw3b.rotation.z+=Math.PI*0.5;
	PIEaddElement(lw3b);//switch left
	
	var lw4=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,7.3),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw4.position.set(11.15,-2.17,-1);
	PIEaddElement(lw4); 					//further right side of MM
	
	var lw5=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,3.5),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw5.position.set(9,-4.1,-1);
	PIEaddElement(lw5);                      //left side of MM
	
	var lw5a=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,3.5),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	lw5a.position.set(9.8,-4.1,-1);
	PIEaddElement(lw5a);                      //right side of MM
	
	var lw5b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,7.3),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw5b.position.set(3,-2.17,-1);
	PIEaddElement(lw5b);                      //E.A.
	
	
	var lw6a=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,2.88),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw6a.position.set(-5,-4.18,-0.1);
	PIEaddElement(lw6a);						//battery bottom left
	
	
	var lw6b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,2.9),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw6b.position.set(-5,-0.1,-0.1);
	PIEaddElement(lw6b);						//battery upper 
	
	
	var lw8=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,15.8),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw8.position.set(2.85,1.4,-0.1);
	 lw8.rotation.z+=Math.PI*0.5;
	PIEaddElement(lw8);
	
}

function stopdeflection()
{
	aneedle.rotation.z=0;
	needle.rotation.z=0;
	lampBulb.material.color.set(0xFFFFFF);
}

function addBulb()
{
    var lampBottomGeom = new THREE.CylinderGeometry(0.2, 0.2, 0.4, 12);
    var lampBottom = new THREE.Mesh(lampBottomGeom, new THREE.MeshPhongMaterial({color: "gray", shininess: 0}));
    lampBottom.position.set(3.3, -2, -0.5);
	lampBottom.rotation.x=+Math.PI/8;
    PIEaddElement(lampBottom);

    var lampBulbGeom = new THREE.SphereGeometry(0.8, 32, 24);
    lampBulbGeom.translate(0, 1, 0);
    lampBulb = new THREE.Mesh(lampBulbGeom, new THREE.MeshPhongMaterial({color: 0xffffff, transparent: true, opacity:0.8}));
    lampBottom.add(lampBulb);

    var baseGeom = new THREE.BoxGeometry( 1.6, 0.8,0.7  );
    baseGeom.translate(0,-0.4,0);
    var base = new THREE.Mesh(baseGeom, new THREE.MeshPhongMaterial( {color:"gray"} ));

    var edges = new THREE.EdgesGeometry( baseGeom );
    var line = new THREE.LineSegments( edges, new THREE.LineBasicMaterial( { color: 0x000 } ) );
    
    lampBottom.add( line );
    lampBottom.add(base);
	
	lampBottom.rotation.z=-Math.PI/2;
	lampBottom.rotation.x=-Math.PI/60;
}

function switch_off()
{
	Switch.position.set(-0.95,-5.14,1);
	//Switch.position.set(-0.9,-5.39,1);
	Switch.rotation.z=-Math.PI/2-Math.PI/3;
}

function switch_on()
{
	Switch.rotation.z=0;
	Switch.position.set(-0.9,-5.39,1);
}

function maketable()
{
	if(lm==0)
	{
	if(ab>5)
		ab=2;
	PIEtableSelect("Experimental Data");
	PIEupdateTableCell(ab,0,voltage);
	PIEupdateTableCell(ab,1,((voltage/resistance)*1000).toFixed(2));
	PIEupdateTableCell(ab,2,resistance);
	PIEupdateTableCell(ab,3,(((voltage*voltage)/resistance).toFixed(2)));
	
	ab++;
	}
	else
	{
		PIEtableSelect("Experimental Data.");
		PIEupdateTableCell(2,0,voltage);
		PIEupdateTableCell(2,1,((voltage/resistance)*1000).toFixed(2));
		PIEupdateTableCell(2,2,resistance);
	}
}

function resettable()
{
	PIEupdateTableCell(2,0,"-");
	PIEupdateTableCell(2,1,"-");
	PIEupdateTableCell(2,2,"-");
	PIEupdateTableCell(2,3,"-");
	
	PIEupdateTableCell(3,0,"-");
	PIEupdateTableCell(3,1,"-");
	PIEupdateTableCell(3,2,"-");
	PIEupdateTableCell(3,3,"-");
	
	PIEupdateTableCell(4,0,"-");
	PIEupdateTableCell(4,1,"-");
	PIEupdateTableCell(4,2,"-");
	PIEupdateTableCell(4,3,"-");
	
	PIEupdateTableCell(5,0,"-");
	PIEupdateTableCell(5,1,"-");
	PIEupdateTableCell(5,2,"-");
	PIEupdateTableCell(5,3,"-");
}

function learningmode()
{
	PIEchangeInputCheckbox("Learning Mode", true, learningmode);
	PIEchangeInputCheckbox("Experiment Mode", false, learningmode);
	document.getElementById("mytable").style.visibility="hidden";
	document.getElementById("mytable2").style.visibility="visible";
	power.visible=true;
	power2.visible=true;
	power3.visible=true;
	PIEtableSelect("Experimental Data.");
	PIEupdateTableCell(2,0,'-');
	PIEupdateTableCell(2,1,'-');
	PIEupdateTableCell(2,2,'-');
	var a=Math.floor(Math.random()*230);
	if(a<5)
		a=5;
	//alert(a);
	voltagecontrol(a);
	PIEchangeInputSlider("Voltage", a);
	/**/
	powerplain.visible=true;
	PIErender();
	lm=1;
	}

function experimentmode()
{
	PIEchangeInputCheckbox("Learning Mode", false, learningmode);
	PIEchangeInputCheckbox("Experiment Mode", true, learningmode);
	document.getElementById("mytable").style.visibility="visible";
	document.getElementById("mytable2").style.visibility="hidden";
	resettable();
	power.visible=false;
	power2.visible=false;
	power3.visible=false;
	powerplain.visible=false;
	lm=0;
	PIErender();
}

function addElementsToScene()
{
	PIEaddInputSlider("Voltage", 5, voltagecontrol, 5, 230, 1);
	
	PIEcreateTable("Experimental Data", 6, 4, true);
    var headerRow=["Voltage|", "Current|", "Resistance|", "Power"];
	PIEupdateTableRow(0, headerRow);
	var headerRow=["  (V)  ","   (mA)  ","  (Ohm)  ","  (W)  "];
	PIEupdateTableRow(1,headerRow);
	resettable();
	
	PIEaddInputCheckbox("Learning Mode", false, learningmode);
	PIEaddInputCheckbox("Experiment Mode", true, experimentmode);
	
	PIEcreateTable1("Experimental Data.",3,3,true);
	var headerRow=["Voltage|", "Current|", "Resistance"];
	PIEupdateTableRow(0, headerRow);
	var headerRow=["  (V)  ","   (mA)  ","  (Ohm)  "];
	PIEupdateTableRow(1,headerRow);
	PIEupdateTableCell(2,0,'-');
	PIEupdateTableCell(2,1,'-');
	PIEupdateTableCell(2,2,'-');
	document.getElementById("mytable2").style.visibility="hidden";
	 
	lm=0;
	check=1;
	flag=0;
	addText();
	addMeter();
	addBulb();
	addWires();
	addAmmeter();
	addClipper();
	addMM();
	addclock();
	learningtext();
	addclocktext();
	//addArrows();
	mybattery(0,0,0);
}

function initialisescene()
{
	PIEscene.background = new THREE.Color( 0x287A4C );
	
	var light =new THREE.PointLight( 0xffff66 ,0.7,100);
	light.position.set(0,0,50);
	PIEaddElement(light);
	
}

function loadExperimentElements()
{
	ab=2;
	resistance=1500;
	voltage=5;
	a=0;
	b=0;
	initialiseHelp();
	initialiseInfo();
	initialisescene();
	addElementsToScene();
	
	PIEsetExperimentTitle("Simple power (wattage) calculations");
    PIEsetDeveloperName("Aryaman");

	if(window.outerWidth<700&&window.outerWidth>600)
	{
		alert(window.outerWidth);
		var q=2.5;
		PIEsetAreaOfInterest(-11*q, 5*q/2.2,12*q,- 7*q/2.2);
	}
	else if(window.outerWidth<=600&&window.outerWidth>450)
	{
		alert(window.outerWidth);
		PIEsetAreaOfInterest(-11*2, 5*1.4,12*2,- 7*1.4);
	}
	else if(window.outerWidth<=450&&window.outerWidth>400)
	{
		alert(window.outerWidth);
		PIEsetAreaOfInterest(-11*4, 5*1.6,12*4,- 7*1.6);
	}
	else if(window.outerWidth<=400)
	{
		alert(window.outerWidth);
		PIEsetAreaOfInterest(-11*5, 5*1.9,12*5,- 7*1.9);
	}
	else
		PIEsetAreaOfInterest(-11, 7,12,- 7);
	
}

function PIEstartAnimation()
{
	battext.visible=false;
	if(PIEanimationON==false){PIElastUpdateTime=Date.now();PIEpauseOffset=0;PIEcurrentTime=0;PIEoffsetTime=0;PIEanimationON=true;PIEanimationPaused=false;PIEresumeButton.style.display="none";PIEresumeButton.style.visibility="hidden";PIEpauseButton.style.display="inline";PIEpauseButton.style.visibility="visible";PIEstartButton.style.display="none";PIEstopButton.style.display="inline";PIEshowDisplayPanel();PIEanimate()}
	startText();
	switch_on();
	deflection();
	flag=2;
	//bulb_on();
	maketable();
	clockzero();
	a=0;
	b=0;
	calc = ((voltage*voltage)/resistance).toFixed(2);
	batterytext();
	//alert(window.innerWidth);
}

function PIEstopAnimation()
{
	if(PIEanimationON==true){PIEpauseOffset=0;PIEcurrentTime=0;PIEoffsetTime=0;PIEanimationON=false;PIEanimationPaused=false;PIEresumeButton.style.display="none";PIEresumeButton.style.visibility="hidden";PIEpauseButton.style.display="inline";PIEpauseButton.style.visibility="hidden";PIEstopButton.style.display="none";PIEstartButton.style.display="inline";PIEshowInputPanel()}
	stopdeflection();	
	switch_off();
	stopText();
	PIErender();
}

function resetExperiment()
{
	switch_off();
	stopdeflection();
	stopText();
	PIEchangeInputSlider("Voltage",5);
	voltagecontrol(5);
	resettable();
	clockzero();
	a=0;
	b=0;
	PIErender();
}

function updateExperimentElements(t, dt) 
{  

  /*information.style.top = window.innerWidth*0.8/10  + "px";
  information.style.right = -window.innerHeight*4.5/10 + "px";
  
information.innerHTML = min + ":" + sec;*/
/*sec[10].visible=true;
min[58].visible=true;*/
if(flag%2==0)
{
a++;
if(a>59)
{
	a=0;
	b++;
}
if(b==60)
{
	clockzero();
	
}
if(a>0)
sec[a-1].visible=false;
else
sec[59].visible=false;
if(b>0)
min[b-1].visible=false;
sec[a].visible=true;
min[b].visible=true;
}
}